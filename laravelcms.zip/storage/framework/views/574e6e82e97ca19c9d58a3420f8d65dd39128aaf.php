<?php $__env->startSection('title', $page['title']); ?>

<?php $__env->startSection('content'); ?>
   <!-- bradcam_area  -->
<div class="bradcam_area bradcam_bg_1">
    <div class="container">
        <div class="row">
            <div class="col-xl-12">
                <div class="bradcam_text">
                    <h3><?php echo e($page['title']); ?></h3>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /bradcam_area  -->

<div class="container my-4">
    <?php echo $page['body']; ?>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('site.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\b7web\laravel\laravel6\cms\laravelcms\resources\views/site/page.blade.php ENDPATH**/ ?>