<?php $__env->startSection('title', 'Páginas'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>
        Minhas Páginas
        <a class="btn btn-sm btn-success" href="<?php echo e(route('pages.create')); ?>">Nova Página</a>
    </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="card">
    <div class="card-body">
        <table class="table table-hover">
            <thead>
            <tr>
                <th width="50">ID</th>
                <th>Título</th>
                <th width="200">Ações</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($page->id); ?></td>
                    <td><?php echo e($page->title); ?></td>
                    <td>
                        <a class="btn btn-sm btn-success" href="" target="_blank">Ver</a>
                        <a class="btn btn-sm btn-info" href="<?php echo e(route('pages.edit', ['page' => $page->id])); ?>">Editar</a>
                        <form class="d-inline" method="POST" action="<?php echo e(route('pages.destroy', ['page' => $page->id])); ?>" onsubmit="return confirm('Tem certeza que deseja excluir?')">
                            <?php echo method_field('DELETE'); ?>
                            <?php echo csrf_field(); ?>
                            <button class="btn btn-sm btn-danger">Excluir</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php echo e($pages->links()); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\b7web\laravel\laravel6\cms\laravelcms\resources\views/admin/pages/index.blade.php ENDPATH**/ ?>